(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"Archive search","last":"Scheduled search","num":"10","node":"gdata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
