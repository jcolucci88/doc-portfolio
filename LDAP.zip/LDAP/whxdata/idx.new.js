(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"Authenticate LDAP","last":"Enable Two-Factor Authentication","num":"2","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
