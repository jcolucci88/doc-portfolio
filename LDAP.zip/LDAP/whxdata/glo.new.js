(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"Active Directory","last":"WHOIS","num":"56","node":"gdata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
