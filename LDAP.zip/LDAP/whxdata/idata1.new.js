(function() {
var index =  {"type":"data","keys":[{"name":"Authenticate LDAP","type":"key","topics":[{"name":"LDAP Authentication","type":"topic","url":"Account_Management/LDAP/LDAP_Authentication.htm"}],"keys":[]},{"name":"Enable Two-Factor Authentication","type":"key","topics":[{"name":"Two Factor Settings","type":"topic","url":"Account_Management/Two-Factor_Settings/Two_Factor_Settings.htm"}],"keys":[]}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
